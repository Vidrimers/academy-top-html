import '../scss/style.scss'
import './lib/swiper.js'
import 'swiper/css'
import './slider-main.js'
import './slider-clients.js'
import './slider-products.js'
import './products-nav.js'
// import './site-nav.js'

console.log('INDEX.JS РАБОТАЕТ')
